package com.cg.mps.dao;

import java.util.ArrayList;
import com.cg.mps.exception.*;
import com.cg.mps.dto.*;
public interface MobileDao {
	public ArrayList<Mobile> display()throws MobilePurchaseException;
	//public int addCust(Purchase p)throws MobilePurchaseException;
	//public int update(int id)throws MobilePurchaseException;
	public int delete(int id)throws MobilePurchaseException;
	public ArrayList<Mobile> search(double min,double max)throws MobilePurchaseException;
}
