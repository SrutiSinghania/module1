package com.cg.mps.dao;
import java.util.ArrayList;
import com.cg.mps.exception.*;
import com.cg.mps.dto.*;
public interface PurchaseDao {
	public int addCust(Purchase p)throws MobilePurchaseException;
}
