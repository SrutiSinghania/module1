package com.cg.mps.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.Timestamp;
import com.cg.mps.dto.Purchase;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.MobilePurchaseException;
import com.cg.mps.util.DBUtil;
//import com.cg.mps.dto.Purchase;
//import com.cg.mps.exception.MobilePurchaseException;

//import org.apache.log4j.Logger;
//import org.apache.log4j.PropertyConfigurator;

public class PurchaseDaoImpl implements PurchaseDao
{
	
	//Logger daoLogger=null;
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	int data=0;
	int count=0;
	
	/*public EmpDaoImpl()
	{
		daoLogger=Logger.getLogger(EmpDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
	}*/
	@Override
	public int addCust(Purchase p) throws MobilePurchaseException 
	{
		// TODO Auto-generated method stub
		//return 0;
		try 
		{
			con=DBUtil.getConn();
			String selectQry="select quantity from mobile where mobile_id="+p.getMobileId();
			st=con.createStatement();
			//pst.setInt(1,mid);
			rs=st.executeQuery(selectQry);
			//while()
				//count++;
			rs.next();
			count=Integer.parseInt(rs.getString("quantity"));
			if(count>0)
			{
				//rs.next();
				System.out.println("Quantity="+count);
				String insertQry="insert into purchasedetail values (id_sequence.nextval,?,?,?,?,?)";
				pst=con.prepareStatement(insertQry);
			//pst.setInt(1, p.getPurchaseId());
				pst.setString(1, p.getCustName());
				pst.setString(2, p.getMailId());
			//pst.setString(3, p.getMailId());
				pst.setString(3, p.getPhoneNo());
				Timestamp date=new Timestamp(new java.util.Date().getTime());
				pst.setTimestamp(4, date);
				pst.setInt(5, p.getMobileId());
				data = pst.executeUpdate();
				count--;
				String updateQry="update mobile set quantity="+count+ "where mobile_id="+p.getMobileId();
				st=con.createStatement();
				rs=st.executeQuery(updateQry);
			}
			else 
				throw new MobilePurchaseException("quantity=0");
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobilePurchaseException(e.getMessage());
		}
		return data;
	}	
}
