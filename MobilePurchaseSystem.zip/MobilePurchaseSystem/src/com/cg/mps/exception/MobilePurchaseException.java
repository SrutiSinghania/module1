package com.cg.mps.exception;

//import com.cg.ems.exception.ErrorCode;

public class MobilePurchaseException extends Exception{
	String msg;
	//static ErrorCode code;
	public MobilePurchaseException(String msg)
	{
		super(msg);
	}
	/*public EmployeeException(String msg,Throwable cause,ErrorCode code)
	{
		super(msg,cause);
	}*/
}
