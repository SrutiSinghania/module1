package com.cg.mps.service;

import java.util.regex.Pattern;

//import com.cg.ems.exception.EmployeeException;
//import com.cg.ems.dao.EmpDaoImpl;
import com.cg.mps.dao.PurchaseDao;
import com.cg.mps.dao.PurchaseDaoImpl;
import com.cg.mps.dto.Purchase;
import com.cg.mps.exception.MobilePurchaseException;

public class PurchaseServiceImpl implements PurchaseService{

	PurchaseDao obj=null;
	public PurchaseServiceImpl()
	{
		obj=new PurchaseDaoImpl();
	}
	@Override
	public int addCust(Purchase p) throws MobilePurchaseException {
		// TODO Auto-generated method stub
		return obj.addCust(p);
	}
	@Override
	public boolean validateCustName(String ename) throws MobilePurchaseException
	{
		String namePattern="[A-Z][a-z]{1,20}";
		if(Pattern.matches(namePattern, ename))
			return true;
		else
		{
			throw new MobilePurchaseException("\nMaximum 20 characters allowed and start with capital letter only");
		}
	}
	public boolean validatePhoneNo(String pno) throws MobilePurchaseException
	{
		String numberPattern="[0-9]{10}";
		if(Pattern.matches(numberPattern, pno))
			return true;
		else
		{
			throw new MobilePurchaseException("\nMobile number should contain exactly 10 digits.");
		}
	}
	public boolean validateMobileId(int mid) throws MobilePurchaseException
	{
		String numberPattern="[0-9]{4}";
		if(Pattern.matches(numberPattern, Integer.toString(mid)))
			return true;
		else
		{
			throw new MobilePurchaseException("\nMobile id should have exactly 4 digits");
		}
	}
	public boolean validateEmailId(String mailid) throws MobilePurchaseException
	{
		String namePattern="[a-z0-9_.]+@[a-z]+.[a-z]+";
		if(Pattern.matches(namePattern, mailid))
			return true;
		else
		{
			throw new MobilePurchaseException("\nEmail id is invalid.");
		}
	}
}
