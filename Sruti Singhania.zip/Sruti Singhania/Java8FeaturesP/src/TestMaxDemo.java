
public class TestMaxDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MaxFinder mf= (a,b)->(a>b? a:b);
		System.out.println("Greatest number is:"+mf.max(80,67));
		
	}
}
