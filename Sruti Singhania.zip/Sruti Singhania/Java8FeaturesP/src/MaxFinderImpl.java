
public class MaxFinderImpl implements MaxFinder{

	@Override
	public int max(int a, int b) {
		// TODO Auto-generated method stub
		
		return (a>b? a:b);
	}
	
}
