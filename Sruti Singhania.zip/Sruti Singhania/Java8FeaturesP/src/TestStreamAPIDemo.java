import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
public class TestStreamAPIDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> intList=Arrays.asList(45,8,10,3,89,456,10);
		Stream<Integer> intListStream=intList.stream(); 
		intListStream.filter(num->num>10).forEach(num->System.out.println(num));
		System.out.println("*****************************");
		intList.stream().distinct().forEach(System.out::println);
		List<String> cityList=Arrays.asList("pune","","mumbai","noida","");
		cityList.stream().map(str->str.length()).forEach(System.out::println);
		long countEmpty=cityList.stream().filter(str->str.isEmpty()).count();
		System.out.println("empty:"+countEmpty);
	}

}
