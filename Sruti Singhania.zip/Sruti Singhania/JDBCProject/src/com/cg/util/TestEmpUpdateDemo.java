package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestEmpUpdateDemo {
	public static void main(String args[])
	{
		Connection con=null;
		PreparedStatement pst=null;

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter emp id whose salary needs to be updated:");
		int id=sc.nextInt();
		//System.out.println("Enter emp name:");
		//String name=sc.next();
		System.out.println("Enter new salary:");
		float sal=sc.nextFloat();
		String updateQry="update Emp_157903 set emp_sal=? where emp_id=?";
		
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg17","lab1boracle");
			pst=con.prepareStatement(updateQry);
			pst.setFloat(1,sal);
			pst.setInt(2,id);
			//pst.setFloat(3,sal);
			int noOfRecUpdated=pst.executeUpdate();
			System.out.println(noOfRecUpdated +" record(s) updated");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
