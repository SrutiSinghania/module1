package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class TestMetadata {
		public static void main(String args[])
		{
			Connection con=null;
			Statement st=null;
			ResultSet rs=null;
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg17","lab1boracle");
				st=con.createStatement();
				rs=st.executeQuery("Select * from Emp_157903");
				System.out.println("Result set meta data");
				ResultSetMetaData rsmd=rs.getMetaData();
				int colCount=rsmd.getColumnCount();
				System.out.println("Number of columns:"+colCount);
				for(int i=1;i<=colCount;i++)
				{
					System.out.println("Column Name:"+rsmd.getColumnName(i)+"Column data type:"+rsmd.getColumnTypeName(i));
				}
				while(rs.next())
				//);
				System.out.println(" : " +rs.getInt("emp_id")+" : "+rs.getString("emp_name")+" : "+rs.getFloat("emp_sal"));
			} 
			catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
}
