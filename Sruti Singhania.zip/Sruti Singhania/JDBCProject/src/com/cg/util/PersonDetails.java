package com.cg.util;

import java.io.*;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;


public class PersonDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileInputStream fis=null;
		Properties myPros=null;
		try
		{
			fis=new FileInputStream("PersonProps.properties");
			myPros=new Properties();
			
			myPros.load(fis);
			System.out.println(myPros);
			
			String id=myPros.getProperty("id");
			String name=myPros.getProperty("name");
			String gender=myPros.getProperty("gender");
			
			
			Set<Object> ks=myPros.keySet();
			Iterator it=ks.iterator();
			while(it.hasNext())
			{
				System.out.print(":"+it.next());
			}
			System.out.println("\n");
			System.out.println(name+":"+gender+":"+id);
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}

}
