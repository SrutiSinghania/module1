package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class TestEmpSelectDemo2 {
	public static void main(String args[])
	{
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter minimum salary:");
		float min=sc.nextFloat();
		System.out.println("Enter maximum salary:");
		float max=sc.nextFloat();
		String qry="Select * from Emp_157903 where emp_sal>=? and emp_sal<=?";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg17","lab1boracle");
			pst=con.prepareStatement(qry);
			pst.setFloat(1,min);
			pst.setFloat(2,max);
			rs=pst.executeQuery();
			while(rs.next())
			//);
			System.out.println(" : " +rs.getInt("emp_id")+" : "+rs.getString("emp_name")+" : "+rs.getFloat("emp_sal"));
		} 
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
