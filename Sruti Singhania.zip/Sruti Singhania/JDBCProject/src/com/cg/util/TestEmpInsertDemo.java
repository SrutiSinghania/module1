package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestEmpInsertDemo {
	public static void main(String args[])
	{
		Connection con=null;
		PreparedStatement pst=null;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter emp id:");
		int id=sc.nextInt();
		System.out.println("Enter emp name:");
		String name=sc.next();
		System.out.println("Enter emp salary:");
		float sal=sc.nextFloat();
		String insertQry="insert into Emp_157903 values (?,?,?)";
		
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg17","lab1boracle");
			pst=con.prepareStatement(insertQry);
			pst.setInt(1,id);
			pst.setString(2,name);
			pst.setFloat(3,sal);
			int noOfRecInserted=pst.executeUpdate();
			System.out.println(noOfRecInserted +" data inserted into the table");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
