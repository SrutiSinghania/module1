package com.cg.util;

import java.util.Scanner;
import java.util.regex.Pattern;

public class TestValidationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your name:");
		String eName=sc.next();
		String namePattern1="[A-Z][a-z]+";
		String namePattern2="[0-9]+";
		System.out.println("You have entered:"+eName);
		if(Pattern.matches(namePattern1, eName))
		{
			System.out.println("Valid Name");
		}
		else
		{
			System.out.println("Invalid Name");
		}
	}

}
