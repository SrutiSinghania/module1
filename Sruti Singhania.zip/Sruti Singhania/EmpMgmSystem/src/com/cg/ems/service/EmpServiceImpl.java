package com.cg.ems.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.ems.dao.EmpDaoImpl;
import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;

public class EmpServiceImpl implements EmpService {
	EmpDaoImpl empDao=null;
	public EmpServiceImpl()
	{
		empDao=new EmpDaoImpl();
	}

	@Override
	public ArrayList<Employee> getAllEmp() throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.getAllEmp();
	}

	@Override
	public int addEmp(Employee ee) throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.addEmp(ee);
		//return 0;
	}

	@Override
	public boolean validateEmpName(String ename) throws EmployeeException
	{
		String namePattern="[A-Z][a-z]+";
		if(Pattern.matches(namePattern, ename))
			return true;
		else
		{
			throw new EmployeeException("Invalid Empolyee Name \n Should Start with capital and only characters are allowed");
		}
	}

}
