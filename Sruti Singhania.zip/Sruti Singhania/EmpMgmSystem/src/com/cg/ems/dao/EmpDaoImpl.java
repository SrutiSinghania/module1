package com.cg.ems.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class EmpDaoImpl implements EmpDao{
	
	Logger daoLogger=null;
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	int data=0;
	
	public EmpDaoImpl()
	{
		daoLogger=Logger.getLogger(EmpDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
	}
	@Override
	public ArrayList<Employee> getAllEmp() throws EmployeeException
	{
		ArrayList<Employee> empList=null;
		try
		{
			empList=new ArrayList<Employee>();
			con=DBUtil.getConn();
			String selectQry="select * from Emp_157903";
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			
			while(rs.next())
			{
				//dao.info(new Employee(rs.getInt("emp_id"),rs.getString("emp_name"),rs.getFloat("emp_sal")));
				empList.add(new Employee(rs.getInt("emp_id"),rs.getString("emp_name"),rs.getFloat("emp_sal")));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		finally
		{
			try
			{
				st.close();
				rs.close();
				con.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
				daoLogger.error(e.getMessage());
				throw new EmployeeException(e.getMessage());
			}
		}
		daoLogger.info("All data retrieved \n"+empList);
		// TODO Auto-generated method stub
		return empList;
	}

	@Override
	public int addEmp(Employee ee) throws EmployeeException 
	{
		// TODO Auto-generated method stub
		try {
			con=DBUtil.getConn();
			String insertQry="insert into Emp_157903 values (?,?,?)";
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, ee.getEmpId());
			pst.setString(2, ee.getEmpName());
			pst.setFloat(3, ee.getEmpSal());
			data = pst.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		
		return data;
	}
	

}
