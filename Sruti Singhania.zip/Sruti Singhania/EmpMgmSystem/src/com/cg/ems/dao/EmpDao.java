package com.cg.ems.dao;

import java.util.ArrayList;
import com.cg.ems.exception.*;
import com.cg.ems.dto.*;
public interface EmpDao {
	public ArrayList<Employee> getAllEmp()throws EmployeeException;
	public int addEmp(Employee ee)throws EmployeeException;
}
