
import java.util.Scanner;
//import com.cg.eis.exception.EmployeeException;;

public class EmployeeMain {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		String ins="",des="",id="";
		System.out.println("Enter the employee id:");
		id=sc.nextLine();
		System.out.println("Enter the salary:");
		double salary=sc.nextDouble();
		try {
		if(salary<3000)
			throw new ExceptionCheck();
		if(salary<5000)
		{
			ins="No insurance";
			des="Clerk";
		}
		else if(salary>=5000 && salary<20000)
		{
			ins="Sceheme C";
			des="System Associate";
		}
		else if(salary>=20000 && salary<40000)
		{
			ins="Scheme B";
			des="Programmer";
		}
		else if(salary>=40000)
		{
			ins="Scheme A";
			des="Manager";
		}
		Employee obj=new Employee(id,des,ins,salary);
		obj.display();
		}
		catch(ExceptionCheck e)
		{
			System.out.println(e);
		}
		
	}
}
