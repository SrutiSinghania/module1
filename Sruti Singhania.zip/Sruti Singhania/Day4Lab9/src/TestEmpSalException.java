import org.junit.*;
	import org.junit.Test;
	import static org.junit.Assert.*;

import java.util.Scanner;

	public class  TestEmpSalException
	{
		@Test(expected=ExceptionCheck.class)
		public void checking() throws ExceptionCheck
		{
			Employee emp=new Employee("12345","Programmer","A",2000);
				emp.check();
			
			
		}

}
