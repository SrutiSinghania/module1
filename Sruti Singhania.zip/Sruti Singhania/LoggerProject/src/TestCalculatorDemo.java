import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class TestCalculatorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Logger myLogger=Logger.getLogger(TestCalculatorDemo.class);
		PropertyConfigurator.configure("log4j.properties");
		Scanner sc=new Scanner(System.in);
		myLogger.debug("This is debug message");
		myLogger.warn("This is warn message");
		myLogger.fatal("This is fatal message");
		System.out.println("Enter a:");
		int a=sc.nextInt();
		myLogger.info("User entered a:"+a);
		
		System.out.println("Enter b:");
		int b=sc.nextInt();
		myLogger.info("User entered b:"+b);
		int c=0;
		try
		{
			c=a/b;
			myLogger.info("c:"+c);
			System.out.println("Result:"+c);
		}
		catch(ArithmeticException e)
		{
			myLogger.error(e.getMessage());
			e.printStackTrace();
		}
	}

}
