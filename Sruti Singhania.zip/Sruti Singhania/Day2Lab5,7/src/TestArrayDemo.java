import java.util.Scanner;
public class TestArrayDemo {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of employees:");
		int empCount=sc.nextInt();
		Emp objs[]=new Emp[empCount];
		//System.out.println(obj);
		for(int i=0;i<objs.length;i++)
		{
			System.out.println("Enter Emp id:");
			int empId=sc.nextInt();
			System.out.println("Enter Emp Name:");
			String empName=sc.next();
			System.out.println("Enter Emp Salary:");
			float empSal=sc.nextFloat();
			
			objs[i]=new Emp(empId,empName,empSal);
			
		}
		System.out.println("*****************************");
		for(Emp tempEmp:objs)
		{
			System.out.println(tempEmp);
		}
	}
}
