import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Iterator;
import java.util.Collection;
public class TestHashMapDemo {
	public static void main(String args[])
	{
		HashMap<Long,String> directory=new HashMap<Long,String>();
		directory.put(8888888888L,"AAA");
		directory.put(9999999999L,"BBB");
		directory.put(9876543210L,"CCC");
		directory.put(9879878765L,"DDD");
		directory.put(8888888888L,"AAA");
		System.out.println(directory);
		Set<Map.Entry<Long,String>> mapSet=directory.entrySet();
		Iterator<Map.Entry<Long,String>> it=mapSet.iterator();
		while(it.hasNext())
		{
			Map.Entry<Long,String> entry=it.next();
			System.out.println("Key:"+entry.getKey()+"Name:"+entry.getValue());
		}
		
		Set<Long> kSet=directory.keySet();
		Iterator<Long> itK=kSet.iterator();
		while(itK.hasNext())
		{
			Long key=itK.next();
			System.out.println("Key:"+key);
		}
		
		Collection<String> VSet=directory.values();
		Iterator<String> itV=VSet.iterator();
		while(itV.hasNext())
		{
			String value=itV.next();
			System.out.println("Value:"+value);
		}
	}
}

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             