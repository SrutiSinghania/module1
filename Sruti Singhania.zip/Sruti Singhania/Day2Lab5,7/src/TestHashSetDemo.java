import java.util.HashSet;
import java.util.Iterator;
public class TestHashSetDemo {
	public static void main(String args[])
	{
		HashSet<Integer> intSet=new HashSet<Integer>();
		Integer i1=new Integer(40);
		Integer i2=new Integer(10);
		Integer i3=new Integer(40);
		Integer i4=new Integer(30);
		String str=new String("Hello");
		
		intSet.add(i1);
		intSet.add(i2);
		intSet.add(i3);
		intSet.add(i4);
		//intSet.add(str);
		
		Iterator<Integer> it=intSet.iterator();
		while(it.hasNext())
		{
			//Integer kk=90;
			Integer ii=it.next();
			System.out.println("entry:"+ii);
		}
	}
	
}
