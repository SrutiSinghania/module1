import java.util.ArrayList;
import java.util.Iterator;
public class TestAyyListEmpDemo {
	public static void main(String args[])
	{
		ArrayList<Emp> empList=new ArrayList<Emp>();
		Emp e1=new Emp(1001,"aaa",20000.0F);
		Emp e2=new Emp(1002,"bbb",30000.0F);
		Emp e3=new Emp(1003,"ccc",40000.0F);
		Emp e4=new Emp(1004,"ddd",50000.0F);
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		empList.add(e4);
		Iterator<Emp> itEmp=empList.iterator();
		while(itEmp.hasNext())
		{
			System.out.println("\t"+itEmp.next());
		}
	}
}
