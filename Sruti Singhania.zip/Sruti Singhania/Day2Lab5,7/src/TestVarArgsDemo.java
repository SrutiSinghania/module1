
public class TestVarArgsDemo {
	public int add(int ...nums)
	{
		int sum=0;
		for(int j:nums)
		{
			sum=sum+j;
		}
		return sum;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			TestVarArgsDemo obj1=new TestVarArgsDemo();
			System.out.println("Summation:"+ obj1.add(7,5,8,9));
			System.out.println("Summation:"+ obj1.add());
			
	}

}
