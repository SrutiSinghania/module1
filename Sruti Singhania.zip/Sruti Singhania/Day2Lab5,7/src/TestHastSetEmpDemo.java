import java.util.HashSet;
import java.util.Iterator;
public class TestHastSetEmpDemo {
	public static void main(String args[])
	{
		HashSet<Emp> empSet=new HashSet<Emp>();
		Emp e1=new Emp(1001,"aaa",20000.0F);
		Emp e2=new Emp(1002,"bbb",30000.0F);
		Emp e3=new Emp(1003,"ccc",40000.0F);
		Emp e4=new Emp(1001,"aaa",20000.0F);
		empSet.add(e1);
		empSet.add(e2);
		empSet.add(e3);
		empSet.add(e4);
		Iterator<Emp> itEmp=empSet.iterator();
		while(itEmp.hasNext())
		{
			System.out.println("\t"+itEmp.next());
		}
	}
}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             