import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
//import java.util.Iterator;
public class SortProductNamesWithList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of products:");
		int n=sc.nextInt();
		ArrayList<String> products=new ArrayList<String>(n);
		for(int i=0;i<n;i++)
		{
			products.add(sc.next());
		}
		Collections.sort(products);
		System.out.println("Sorted list:"+products); 
	}

}
