import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;
public class EmpFile {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in); 
		//StringBuilder s=null;
		System.out.println("Enter number of employees:");
		int n=sc.nextInt();
		for(int i=0;i<n;i++)
		{
		System.out.println("Enter Emp ID:");
		String eid=sc.next();
		System.out.println("Enter Emp Salary:");
		double esal=sc.nextDouble();
		System.out.println("Enter Emp Designation:");
		String desig=sc.next();
		Emp obj=new Emp(eid,desig,esal);
		EmployeeServiceImplement ser=new EmployeeServiceImplement(obj);
		ser.addIntoFile(obj);
		//ser.readFromFile();
		}
		FileInputStream fis=null;
		ObjectInputStream ois=null;
		try 
		{
			fis=new FileInputStream("Emp.obj");
			ois=new ObjectInputStream(fis);
			Emp ee=(Emp)ois.readObject();
			System.out.println("Employee Info from file:"+ee);
		}
		catch(ClassNotFoundException | IOException e)
		{
			e.printStackTrace();
		}
		/*FileInputStream fis=null;
		ObjectInputStream ois=null;
		try 
		{
			fis=new FileInputStream("Emp.obj");
			ois=new ObjectInputStream(fis);
			Object obj;
			//Emp ee=(Emp)ois.readObject();
			Emp ee;
			while((ee=(Emp)ois.readObject())!=null)
			{
				if(ee instanceof Emp)
				{
					System.out.println("Employee Info from file:"+ee);
				}
			}
			//System.out.println("Employee Info from file:"+ee);
		}
		catch(ClassNotFoundException | IOException e)
		{
			e.printStackTrace();
		}
		
		for(int i=0;i<n;i++)
		{
			EmployeeServiceImplement ser1 = new EmployeeServiceImplement();
		ser1.readFromFile();
		}*/
		
	}
}
