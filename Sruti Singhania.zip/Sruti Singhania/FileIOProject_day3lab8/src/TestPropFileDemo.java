import java.io.*;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;


public class TestPropFileDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileInputStream fis=null;
		Properties myPros=null;
		try
		{
			fis=new FileInputStream("UserInfo.properties");
			myPros=new Properties();
			myPros.load(fis);
			String unm=myPros.getProperty("userid");
			String pwd=myPros.getProperty("password");
			System.out.println("Credentials:"+unm+":"+pwd);
			
			Set<Object> ks=myPros.keySet();
			Iterator it=ks.iterator();
			while(it.hasNext())
			{
				System.out.print(" : "+it.next());
			}
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}

}
