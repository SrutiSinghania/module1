import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class TestPropsWriteDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileOutputStream fos=null;
		Properties myDBInfo=null;
		try 
		{
			fos=new FileOutputStream("dbInfo.properties");
			myDBInfo=new Properties();
			myDBInfo.setProperty("dbUser", "System");
			myDBInfo.setProperty("dbPwd", "Root");
			myDBInfo.store(fos,"this is the database information");
			System.out.println("Data written in the file");
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}

}
