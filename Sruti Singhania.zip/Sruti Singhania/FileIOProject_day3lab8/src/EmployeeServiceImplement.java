import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

interface EmployeeService {
	String findInsScheme(double salary);
	void display(Emp emp);
}

public class EmployeeServiceImplement implements EmployeeService{
	public EmployeeServiceImplement(Emp emp)
	{
		display(emp);
	}
	
	public EmployeeServiceImplement()
	{
		
	}
	public String findInsScheme(double salary)
	{
		String ins="";
		if(salary<5000)
		{
			ins="No insurance";
		}
		else if(salary>=5000 && salary<20000)
		{
			ins="Sceheme C";
		}
		else if(salary>=20000 && salary<40000)
		{
			ins="Scheme B";
		}
		else if(salary>=40000)
		{
			ins="Scheme A";
		}
		return ins;
	}
	public void display(Emp emp)
	{
		System.out.println("Employee Details:");
		System.out.println("******************");
		System.out.println("Emp Id:"+emp.getEmpId());
		System.out.println("Designation:"+emp.getDesig());
		System.out.println("Salary:"+emp.getSalary());
		System.out.println("Insurance:"+findInsScheme(emp.getSalary()));
		
	}
	public void addIntoFile(Emp obj)
	{
		FileOutputStream fos=null;
		ObjectOutputStream oos=null;
		try 
		{
			fos=new FileOutputStream("Emp.obj");
			
			oos=new ObjectOutputStream(fos);
			//s=new StringBuilder(oos);
			oos.writeObject(obj);
			System.out.println("Employee is written in the file");
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	/*public void readFromFile()
	{
		FileInputStream fis=null;
		ObjectInputStream ois=null;
		try 
		{
			fis=new FileInputStream("Emp.obj");
			ois=new ObjectInputStream(fis);
			Emp ee=(Emp)ois.readObject();
			System.out.println("Employee Info from file:"+ee);
		}
		catch(ClassNotFoundException | IOException e)
		{
			e.printStackTrace();
		}
	}*/
}
