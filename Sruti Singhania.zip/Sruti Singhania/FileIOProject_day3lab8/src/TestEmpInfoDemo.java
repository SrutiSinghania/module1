import java.io.*;
import java.util.Scanner;

public class TestEmpInfoDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in); 
		System.out.println("Enter Emp ID:");
		int eid=sc.nextInt();
		System.out.println("Enter Emp Name:");
		String ename=sc.next();
		System.out.println("Enter Emp Salary:");
		float esal=sc.nextFloat();
		FileOutputStream fos=null;
		DataOutputStream dos=null;
		try 
		{
			fos=new FileOutputStream("EmpInfo.txt");
			dos=new DataOutputStream(fos);
			dos.writeInt(eid);
			dos.writeUTF(ename);
			dos.writeFloat(esal);
			System.out.println("All Info written in the File");
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}

}
