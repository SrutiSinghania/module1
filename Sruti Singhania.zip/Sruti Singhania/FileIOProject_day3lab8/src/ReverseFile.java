
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReverseFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File myFile=new File("D://Sruti Singhania/FileIOProject/src/TestEmpReadDemo.java");
		String rev="";
		FileReader fr=null;
		FileWriter fw=null;
		BufferedReader br=null;
		BufferedWriter bw=null;
		try {
			fr=new FileReader(myFile);
			br=new BufferedReader(fr);
			fw=new FileWriter("MyFile1.txt");
			bw=new BufferedWriter(fw);
			String line=br.readLine();
			while(line!=null)
			{
				rev=line+rev;
				//System.out.println(line);
				//bw.write(rev);
				//bw.flush();
				line=br.readLine();
			}
			bw.write(rev);
			bw.flush();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}

}
