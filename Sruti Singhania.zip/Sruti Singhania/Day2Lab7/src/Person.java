import java.util.Scanner;

public class Person{
	String firstName;
	String lastName;
	char gender;
	float age;
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	
	Person()
	{
		firstName="";
		lastName="";
		gender=' ';
		age=0;
	}
	Person(String f,String l,char g,float a)
	{
		firstName=f;
		lastName=l;
		gender=g;
		age=a;
		try {
			if(firstName==null && lastName==null)
				throw new NameValidation();
			if(age<=15)
				throw new AgeValidation();
			
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter initial balance for"+firstName);
			double inibal=sc.nextDouble(); 
			//Account a1=new Account(inibal,this);
			//a1.deposit(2000);
			//System.out.println("Account Number of "+firstName+ " Account:"+a1.getAccNum());
			//System.out.println("Balance in "+firstName+ " Account:"+a1.getBalance());
			//display();
			//Account a1=new Account(2000,this);
		}
		catch(NameValidation e)
		{
			System.out.println(e);
		}
		catch(AgeValidation e)
		{
			System.out.println(e);
		}
	}
	public void display()
	{
		System.out.println("First Name:"+firstName);
		System.out.println("Last Name:"+lastName);
		System.out.println("Gender:"+gender);
		System.out.println("Age:"+age);
	}
	
}
class NameValidation extends Exception{
	@Override
	public String toString()
	{
		return "Error:Enter full name";
	}
}
class AgeValidation extends Exception{
	@Override
	public String toString()
	{
		return "Age should be above 15";
	}
}
