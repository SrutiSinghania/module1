
public class WithdrawFromAccount extends Account {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		@Override
		public void withdraw(double amount)
		{
			if(balance>=500)
				balance=balance-amount;
			else
				System.out.println("Minimum balance:Withdraw not possible");
		}
	}

}
