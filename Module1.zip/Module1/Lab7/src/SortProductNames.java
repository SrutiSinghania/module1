import java.util.Arrays;
import java.util.Scanner;
public class SortProductNames {
	public static void main(String args[])
	{
		int n;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of products:");
		n=sc.nextInt();
		String product[]=new String[n];
		System.out.println("Enter the product names:");
		for(int i=0;i<n;i++)
		{
			product[i]=sc.next();
		}
		Arrays.sort(product);
		for(int i=0;i<n;i++)
		{
			System.out.println(product[i]);
		}
	}
}
