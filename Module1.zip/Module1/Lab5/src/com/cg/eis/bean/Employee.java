package com.cg.eis.bean;
public class Employee {
	String empId,desig,insuranceScheme;
	double salary;
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getDesig() {
		return desig;
	}
	public void setDesig(String desig) {
		this.desig = desig;
	}
	public String getInsuranceScheme() {
		return insuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	/*public Employee()
	{
		System.out.println("default constructor");
	}*/
	
	public Employee(String id,String d,double s)
	{
		empId=id;
		salary=s;
		desig=d;
	}
	/*void display()
	{
		System.out.println("Employee Id:"+empId);
		System.out.println("Designation:"+desig);
		System.out.println("Salary:"+salary);
		System.out.println("Insurance Scheme:"+insuranceScheme);
	}*/
}
