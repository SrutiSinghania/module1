import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class TestPerson1 {
	@Test
	public void testGetFirstName()
	{
		//System.out.println("from TestPerson2");
		Person1 per = new Person1();
		per.setFirstName("Sruti");
		assertEquals("Sruti",per.getFirstName());
	}
	
	@Test
	public void testLasName()
	{
		Person1 per = new Person1();
		per.setLastName("Singhania");
		assertEquals("Singhania",per.getLastName());		
	}
	@Test
	public void testGender()
	{
		Person1 per = new Person1();
		per.setGender('F');
		assertEquals('F',per.getGender());		
	}
	@Test
	public void testAge()
	{
		Person1 per = new Person1();
		per.setAge(22);
		//System.out.println(per.getAge());
		assertEquals(22,per.getAge());
		
	}
	@Test
	public void testDisplay()
	{
		Person1 per = new Person1("Sruti","Singhania",'F',22);
		String s=per.display();
		//System.out.println(s);
		assertNotNull(s);
		
	}
}
