import org.junit.Test;

import static org.junit.Assert.*;
public class TestDate {
	@Test
	public void testDay()
	{
		Date obj=new Date(21,8,2018);
		obj.setDay(12);
		assertEquals(12,obj.getDay());
	}
	@Test
	public void testMonth()
	{
		Date obj=new Date(21,6,2018);
		obj.setMonth(8);
		assertEquals(8,obj.getMonth());
	}
	@Test
	public void testYear()
	{
		Date obj=new Date(21,8,2013);
		obj.setYear(2018);
		assertEquals(2018,obj.getYear());
	}
}