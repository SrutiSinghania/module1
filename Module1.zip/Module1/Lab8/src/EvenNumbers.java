import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class EvenNumbers {
	public static void main(String args[])
	{
		try
		{
			FileWriter fw=new FileWriter("Numbers.txt");
			fw.write("0,1,2,3,4,5,6,7,8,9,10");
			fw.flush();
			Scanner sc=new Scanner(new File("Numbers.txt"));
			//System.out.println(sc);
			sc.useDelimiter(",");
			while(sc.hasNext())
			{
				int num=sc.nextInt();
				//System.out.println(num);
				if(num%2==0)
					System.out.println(num);
			}
				
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
}
