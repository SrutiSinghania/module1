import java.io.Serializable;

public class Employee implements Serializable{
	int empId;
	String ename;
	float esal;
	
	public Employee() {}

	public Employee(int empId, String ename, float esal) {
		super();
		this.empId = empId;
		this.ename = ename;
		this.esal = esal;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", ename=" + ename + ", esal=" + esal + "]";
	}

}
