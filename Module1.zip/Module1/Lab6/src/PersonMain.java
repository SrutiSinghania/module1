import java.util.Scanner;


public class PersonMain{
	public static void main(String args[])
	{
		Person obj=new Person(null,null,'f',45);
	}
}
