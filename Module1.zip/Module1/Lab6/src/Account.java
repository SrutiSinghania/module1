
public class Account {
	static int n=1;
	private long accNum;
	private double balance;
	private Person accHolder;
	public long getAccNum(){
		return accNum;
	}
	Account(double b,Person p1)
	{
		accNum=n;
		n++;
		balance=b;
		accHolder=p1;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public void deposit(double amount)
	{
		balance=balance+amount;
	}
	public void withdraw(double amount)
	{
		if(balance>=500)
		balance=balance-amount;
		else
			System.out.println("Minimum balance:Withdraw not possible");
	}
}
